Project Name: Easel Lite

Author: Jon Curnutt

Resources:
- Webpack: compiles different modules into a single file to be run
- React: allowed the use of state to keep track of changes to forms
- Redux: alowed the use of a store that allowed components to access gloabl data
- React-Router: allowed the use of routes so mulitple "pages" can be navigated
- Sass: more stylable css

Special Instructions:
- when adding a class, you must click on a name in the dropdown list even if it looks
     like there is an option selected by default. If you do not select one, a teacher will not be 
     sent in to the database, and a new class will not be created.


Weaknesses:
- Classes DO update correctly in the database when saved, but they do no display data correctly on my page.
     After updating a class the API displays the changes, but my front-end does not.
          ***Update seems to behave correctly sometimes, but not always***

- Save button does not behave correctly (on "New Class" page and "Class Details" page):
     - disables once if data is incorrect, but reenables after next change regardless of whether or
          not the data is valid.

- Teacher option defaults to smae value every time (always displays 'gfoust' currently), but the    
     value is actually correct.


Strengths:
- All functionality retrieves data from api correctly, and almost always displays correctly

-Routes make the site easier to navigate

-logout button on "Class List" page resets to login page and clears token