export interface State {
    token: string | null;
    detailsclicked: boolean;
    classid: string;
    teachers: string[];
}