
export interface Class {
    department: string;
    number: number;
    title: string;
    teacher: string; 
    _id: string;
}