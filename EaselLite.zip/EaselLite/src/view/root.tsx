import React, { ComponentType } from 'react';
import {Provider} from 'react-redux';
import {store} from '../store/store';
import { BrowserRouter as Router, Redirect, Route, Switch, RouteComponentProps } from 'react-router-dom';
import { Login } from './login';
import { ClassList } from './class-list';
import { ClassDetails } from './class-details';
import { NewClass } from './newclass';

function requireLogin(Component: ComponentType<any>) {
    return (props: RouteComponentProps) => {
      const token = store.getState().token;
      if (token === null) {
        console.log('redirecting to /login');
        return <Redirect to="/"/>;
      }
      else {
        return <Component {...props}/>;
      }
    };
  }

export function Root() {
    return (
        <Provider store={store}>
        <Router basename="/">
            <Switch>
                <Route path="/" exact component={Login}/>
                <Route path="/classes" exact render={requireLogin(ClassList)}/>
                <Route path="/classes" render={requireLogin(ClassDetails)}/>
                <Route path="/addclass" exact render={requireLogin(NewClass)}/>
            </Switch>
        </Router>
        </Provider>
    )
}