import React, { SyntheticEvent } from 'react';
import { Class } from '../models/classes';
import { store } from '../store/store';
import './styles.scss';
import { detailsClicked, changeId, login } from '../store/actions';
import { RouteComponentProps} from 'react-router';
import { getClasses } from '../api/getclasses';
import { getDetails } from '../api/getdetails';

interface ClassListState {
    classes: Class[]
}

export class ClassList extends React.Component<RouteComponentProps, ClassListState>{
    state = {
        classes: [] as Class[]
    }

    async componentWillMount() {
        this.setState({classes: await getClasses()});
        console.log(this.state.classes);
    }

    handleClick = async (e: SyntheticEvent, c: Class) => {
        e.preventDefault();
        store.dispatch(changeId(c._id));
        store.dispatch(detailsClicked(true));
        let details = await getDetails(c._id);
        this.props.history.push(`/classes/${details.department}-${details.number}`);
    }

    newClass(){
        this.props.history.push("/addclass");
    }

    logout() {
        store.dispatch(login(" "));
        this.props.history.push("/");
    }

    render() {
        if(this.state.classes && this.state.classes.length){
            return (
                <>
                <h1>Class List</h1>
                <table className="table">
                    <tbody>    
                    {   
                        this.state.classes.map(c =>
                            <tr key={c._id}>
                                <td>{c.department}</td>
                                <td>{c.number}</td>
                                <td>-</td>  
                                <td>{c.title} </td>  
                                <td className="link" onClick={(e) => this.handleClick(e, c)}>
                                    details
                                </td>
                            </tr>
                            ) 
                    } 
                    </tbody>
                </table>
                <div className="link" onClick={() => this.newClass()}>Create new class...</div>
                <div><input type="button" value="Log Out" onClick={() => this.logout()}/></div>
                </>
                )}

        else {
            return (
                <>
                    <h1>Class List</h1>
                    <h3>No Classes</h3>
                </>
                );
        }     
    }
}