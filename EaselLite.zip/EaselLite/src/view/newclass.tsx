import React, { ChangeEvent, FormEvent } from 'react';
import { RouteComponentProps } from 'react-router';
import { store } from '../store/store';
import { getTeachers } from '../api/getTeachers';
import './styles.scss';
import { api } from '../config';

export interface NewClassState {
    department: string;
    number: number;
    title: string;
    teacher: string;
    teachers: string[];
    disable_button: boolean;
    changed: boolean;
}

export class NewClass extends React.Component<RouteComponentProps, NewClassState>{

    state = { 
        department: '',
        number: 0,
        title: '',
        teacher: '',
        teachers: [],
        disable_button: true,
        changed: false,
    }

    async componentWillMount() {
        await getTeachers();
        this.setState( { teachers: store.getState().teachers } );
    }

    save = async (event: FormEvent) => {
        event.preventDefault();
        const newclass = {
            department: this.state.department,
            number: this.state.number.toString(10),
            title: this.state.title,
            teacher: this.state.teacher,
        }
        let token = store.getState().token;
        try{
            console.log("newclass is: " + JSON.stringify(newclass));
            const response = await fetch(`http://${api.server}:${api.port}${api.path}classes`, {
                method: 'POST',
                mode: 'cors',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                },
                body: JSON.stringify({
                    department: newclass.department, 
                    number: newclass.number,
                    title: newclass.title,
                    teacher: newclass.teacher
                    })
            });

            if(response.ok){
                const data = await response.json();
                console.log("new class: " + JSON.stringify(data));
                this.props.history.push("/classes");
            }
            else{
                console.log("something went wrong adding class");
            }
        }
        catch(err){
            console.log(err);
        }  
    }

    handleCancel = (event: FormEvent) => {
        event.preventDefault();
        let result: boolean;
        if(this.state.changed == true){
            result = window.confirm("Discard changes?");
            if(result == true){
                this.props.history.push("/classes");
            }
        }
        else{
            this.props.history.push("/classes");
        }
    }

    updateDepartment = (evt: ChangeEvent<HTMLInputElement>) => {
        this.setState({ department: evt.currentTarget.value});
        if(this.state.department.length == 3){
            this.setState({disable_button: false});
        } 
        this.setState({changed: true});
    }
    
    updateNumber = (evt: ChangeEvent<HTMLInputElement>) => {
        this.setState({ number: parseInt(evt.currentTarget.value, 10)});
        if(this.state.number.toString().length < 2){
            this.setState({disable_button: false});
        }
        if(this.state.number.toString().length > 3){
            this.setState({disable_button: false});
        }
        this.setState({changed: true});
    }

    updateTitle = (evt: ChangeEvent<HTMLInputElement>) => {
        this.setState({ title: evt.currentTarget.value});
        this.setState({disable_button: false});
        this.setState({changed: true});
    }

    updateTeacher = (evt: ChangeEvent<HTMLSelectElement>) => {
        console.log(evt.currentTarget.value);
        this.setState({ teacher: evt.currentTarget.value});
        this.setState({disable_button: false});
        this.setState({changed: true});
    }


    render() {
        let teachers = store.getState().teachers;
        return (
            <>
            <form onSubmit={this.save}>
                <h3>New Class</h3>
                <table>
                <tbody>
                    <tr>
                        <td>Department:</td>
                        <td><input className="input" maxLength={4} minLength = {4} name="department" 
                            required type="text" onChange={this.updateDepartment}/>
                        </td>
                    </tr>
                    <tr>
                        <td>Number:</td>
                        <td>
                            <input className="input" max={999} min={100} name="number" 
                                required type="number" onChange={this.updateNumber}/>
                        </td>
                    </tr>
                    <tr>
                        <td>Title:</td>
                        <td>
                            <input className="input" name="title" 
                                required type="text" onChange={this.updateTitle}/>
                        </td>
                    </tr>
                    <tr>
                        <td>Teacher:</td>
                        <td>
                            <select className="input" name="teacher" required 
                            value= {this.state.teacher} onChange={this.updateTeacher}>
                                { teachers.map(t =>
                                    <option key={Math.random() * (5000000 - 0) + 0}>{t}</option>
                                    )
                                }
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                        <input value="Cancel" type="button" onClick={this.handleCancel}/>
                        <input value="Save"  type="submit" disabled={this.state.disable_button}/>
                        </td>
                    </tr>
                </tbody>
                </table>
            </form>
            </>
        )
    }
}