import React, { FormEvent, ChangeEvent } from 'react';
import { RouteComponentProps } from 'react-router';
import { api } from '../config';
import { login } from '../store/actions';
import { store } from '../store/store';

interface LogInState {
    username: string;
    password: string;
    status: string | null;
}

export class Login extends React.Component<RouteComponentProps, LogInState> {

    state = {
        username: '',
        password: '',
        status: null
    }

    attemptLogIn = async (event: FormEvent) => {
        event.preventDefault();
        let logindata = JSON.stringify({
            username: this.state.username,
            password: this.state.password
        });
        try {
            console.log('Login attempted...');

            const response = await fetch(`http://${api.server}:${api.port}${api.path}login`, {
                method: 'POST',
                mode: 'cors',
                headers: {'Content-Type': 'application/json'},
                body: logindata,
            });
            if(response.ok){
                const data = await response.json();
                console.log("Login succesful... data returned: " + JSON.stringify(data));
                if(data.login){
                  const token = data.token;
                  store.dispatch(login(token));
                  this.props.history.push("/classes");
                }
            }

            
          else {
            this.setState({ status: 'Invalid username / password' });
          }
        }
        catch (err) {
          console.error(err);
        }
      }
    
      updateUsername = (evt: ChangeEvent<HTMLInputElement>) => {
        this.setState({ username: evt.currentTarget.value});
      }
    
      updatePassword = (evt: ChangeEvent<HTMLInputElement>) => {
        this.setState({ password: evt.currentTarget.value});
      }
    
      render() {
        return (
          <div>
            <h1>Log In</h1>
            <form onSubmit={this.attemptLogIn}>
              <table>
                <tbody>
                  <tr>
                    <td>Username:</td>
                    <td><input type="text" onChange={this.updateUsername}/></td>
                  </tr>
                  <tr>
                    <td>Password:</td>
                    <td><input type="password" onChange={this.updatePassword}/></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td className="error">{this.state.status}</td>
                  </tr>
                </tbody>
              </table>
              <input type="submit" value="Log In" />
            </form>
          </div>
        );
      }
}