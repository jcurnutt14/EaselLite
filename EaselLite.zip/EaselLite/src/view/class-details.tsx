import React, { ChangeEvent, FormEvent } from 'react';
import { RouteComponentProps } from 'react-router';
import { getDetails } from '../api/getdetails';
import { store } from '../store/store';
import { getTeachers } from '../api/getTeachers';
import './styles.scss';
import { Class } from '../models/classes';
import { api } from '../config';

interface ClassDetailsState {
    department: string;
    number: number;
    title: string;
    teacher: string;
    teachers: string[];
    id: string;
    disable_button: boolean;
    changed: boolean;
}


export class ClassDetails extends React.Component<RouteComponentProps, ClassDetailsState>{

    state = { 
            department: '',
            number: 0,
            title: '',
            teacher: '',
            teachers: [],
            id: '',
            disable_button: true,
            changed: false
    }

    async componentWillMount() {        
        let details = await getDetails(store.getState().classid)
        this.setState({
            department: details.department,
            number: details.number,
            title: details.title,
            teacher: details.teacher,
            id: details._id,
        });
        await getTeachers();
        this.setState( { teachers: store.getState().teachers } );
    }

    save = async (event: FormEvent) => {
        event.preventDefault();
        const newclass: Class = {
            department: this.state.department,
            number: this.state.number,
            title: this.state.title,
            teacher: this.state.teacher,
            _id: this.state.id,
        }
        let token = store.getState().token;
        try{
            const response = await fetch(`http://${api.server}:${api.port}${api.path}classes/${newclass._id}`, {
                method: 'PUT',
                mode: 'cors',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                },
                body: JSON.stringify({
                    department: newclass.department, 
                    number: newclass.number,
                    title: newclass.title,
                    teacher: newclass.teacher
                    })
            });

            if(response.ok){
                const data = await response.json();
                this.props.history.push("/classes");
            }
            else{
                console.log("something went wrong updating class");
            }
        }
        catch(err){
            console.log(err);
        }
        
    }

    handleCancel = (event: FormEvent) => {
        event.preventDefault();
        let result: boolean;
        if(this.state.changed == true){
            result = window.confirm("Discard changes?");
            if(result == true){
                this.props.history.push("/classes");
            }
        }
        else{
            this.props.history.push("/classes");
        }
    }

    handleDelete = async (event: FormEvent) => {
        event.preventDefault();
        let result: boolean;
        result = window.confirm("Delete Class?");
        if(result == true){
            try{
                const response = await fetch(`http://${api.server}:${api.port}${api.path}classes/${this.state.id}`, {
                    method: 'DELETE',
                    mode: 'cors',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + store.getState().token
                    },
                    body: JSON.stringify({
                        department: this.state.department, 
                        number: this.state.number,
                        title: this.state.title,
                        teacher: this.state.teacher
                        })
                });
    
                if(response.ok){
                }
                else{
                    console.log("something went wrong updating class");
                }
            }
            catch(err){
                console.log(err);
            }
            this.props.history.push("/classes");
        }
    }

    updateDepartment = (evt: ChangeEvent<HTMLInputElement>) => {
        this.setState({ department: evt.currentTarget.value});
        if(this.state.department.length == 3){
            this.setState({disable_button: false});
        } 
        this.setState({changed: true});
    }
    
    updateNumber = (evt: ChangeEvent<HTMLInputElement>) => {
        this.setState({ number: parseInt(evt.currentTarget.value, 10)});
        if(this.state.number.toString().length < 2){
            this.setState({disable_button: false});
        }
        if(this.state.number.toString().length > 3){
            this.setState({disable_button: false});
        }
        this.setState({changed: true});
    }

    updateTitle = (evt: ChangeEvent<HTMLInputElement>) => {
        this.setState({ title: evt.currentTarget.value});
        this.setState({disable_button: false});
        this.setState({changed: true});
    }

    updateTeacher = (evt: ChangeEvent<HTMLSelectElement>) => {
        this.setState({ teacher: evt.currentTarget.value});
        this.setState({disable_button: false});
        this.setState({changed: true});
    }

    render() {
        console.log("current teacher is: " + JSON.stringify(this.state.teacher));
        let teachers = store.getState().teachers;
        return (
            <>
            <form onSubmit={this.save}>
                <h3>Class Details</h3>
                <table>
                <tbody>
                    <tr>
                        <td>Department:</td>
                        <td><input className="input" maxLength={4} minLength = {4} name="department" 
                            required type="text" value={this.state.department} onChange={this.updateDepartment}/>
                        </td>
                    </tr>
                    <tr>
                        <td>Number:</td>
                        <td>
                            <input className="input" max={999} min={100} name="number" 
                                required type="number" value={this.state.number} onChange={this.updateNumber}/>
                        </td>
                    </tr>
                    <tr>
                        <td>Title:</td>
                        <td>
                            <input className="input" name="title" required type="text" 
                            value={this.state.title} onChange={this.updateTitle}/>
                        </td>
                    </tr>
                    <tr>
                        <td>Teacher:</td>
                        <td>
                            <select className="input" name="teacher" required 
                                value={this.state.teacher} onChange={this.updateTeacher}>
                                { teachers.map(t =>
                                    <option key={Math.random() * (5000000 - 0) + 0}>{t}</option>
                                    )
                                }
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                        <input value="Delete" type="button" onClick={this.handleDelete}/>  
                        <input value="Cancel" type="button" onClick={this.handleCancel}/>
                        <input value="Save"  type="submit" disabled={this.state.disable_button}/>
                        </td>
                    </tr>
                </tbody>
                </table>
            </form>
            </>
        )
    }
}