import { api } from "../config";
import { store } from "../store/store";
import { viewTeachers } from "../store/actions";

export async function getTeachers(){
    let token = store.getState().token;
    console.log(JSON.stringify(token));
    console.log(JSON.stringify(api.login));
    const response = await fetch(`http://${api.server}:${api.port}${api.path}users?role=teacher`, {
        method: 'GET',
        mode: 'cors',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
    });

    if(response.ok){
        const data = await response.json();
        let names: string[] = [];
        for(let i=0; i<data.length; i++){
            names.push(data[i].username)
        }
        console.log("teacher data is " + JSON.stringify(data));
        console.log('teacher array: ' + names);
        store.dispatch(viewTeachers(names));
        return;
    }
    else{
        return [];
    }
}