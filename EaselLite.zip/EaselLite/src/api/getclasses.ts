import { api } from "../config";
import { store } from "../store/store";

export async function getClasses(){
    let token = store.getState().token;
    const response = await fetch(`http://${api.server}:${api.port}${api.path}classes?sort=department+number`, {
        method: 'GET',
        mode: 'cors',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
    });

    if(response.ok){
        const data = await response.json();
        return data;
    }
    else{
        return [];
    }
}