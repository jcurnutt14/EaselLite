export const api = {
    server:   'taz.harding.edu',
    port: 888,
    path: '/api/',
    login: {
        username: 'admin',
        password: 'admin'
    }
}