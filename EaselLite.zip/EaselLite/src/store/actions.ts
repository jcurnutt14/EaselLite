export interface ViewTeachers{
    type: 'AddTeacher';
    teachers: string[];
}

export function viewTeachers(teachers: string[]): ViewTeachers {
    return {
        type: 'AddTeacher',
        teachers
    }
}

export interface Login {
    type: 'Login';
    token: string;
}

export function login(token: string): Login {
    return {
        type: 'Login',
        token,
    }
}

export interface DetailsClicked {
    type: 'DetailsClicked';
    detailsClicked: boolean;
}

export function detailsClicked(detailsClicked: boolean): DetailsClicked {
    return {
        type: 'DetailsClicked',
        detailsClicked
    }
}

export interface ChangeId {
    type: 'ChangeId';
    id: string;
}

export function changeId(id: string): ChangeId {
    return {
        type: 'ChangeId',
        id,
    }
}

export type Action = Login | DetailsClicked | ChangeId | ViewTeachers;