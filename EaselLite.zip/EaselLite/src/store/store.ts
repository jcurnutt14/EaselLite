import * as Redux from 'redux';

import { Action} from "./actions";
import { State } from "../models/state";


function login(state = null as null | string, action: Action)
{
    switch(action.type) {
        case 'Login':
            return action.token;
        default:
            return state;
    }
}

function details(state = false as boolean, action: Action)
{
    switch(action.type) {
        case 'DetailsClicked':
            return action.detailsClicked;
        default:
            return state;
    }
}

function id(state = '' as string, action: Action) {
    switch(action.type) {
        case 'ChangeId':
            return action.id;
        default:
            return state;
    }
}

function teachers(state = [] as string[], action: Action) {
    switch(action.type) {
        case 'AddTeacher':
            return action.teachers;
        default:
            return state;
    }
}

function reducer(state = {} as State, action: Action): State {
   return {
       token: login(state.token, action),
       detailsclicked: details(state.detailsclicked, action),
       classid: id(state.classid, action),
       teachers: teachers(state.teachers, action)
   };
}

export const store = Redux.createStore(reducer);